

class MissingParenthesisException(Exception):
    pass


class DivideByZeroException(Exception):
    pass


class InvalidCharacterException(Exception):
    pass


class TooManyOperatorsException(Exception):
    pass